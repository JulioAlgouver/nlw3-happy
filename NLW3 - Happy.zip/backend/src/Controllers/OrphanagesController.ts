import {Request, Response} from 'express'
import { getRepository } from 'typeorm';
import Orphanage from '../models/Orphanage';
import OrphanagesView from '../Views/OrphanagesView';
import * as yup from 'yup';

export default {
    async index(request:Request, response:Response){
        const orphanagesRepository = getRepository(Orphanage);

        const orphanages = await orphanagesRepository.find({
            relations:['images']
        });

        response.status(201).json(OrphanagesView.renderMany(orphanages));
    },

    async show(request:Request, response:Response){
        const {id} = request.params;

        const orphanagesRepository = getRepository(Orphanage);
   
        const orphanage = await orphanagesRepository.findOneOrFail(id, {
            relations:['images']
        });

        response.status(201).json(OrphanagesView.render(orphanage));
    },

    async create(request: Request, response:Response) {
        const {
            name,
            latitude,
            longitude,
            about,
            instructions,
            opening_hours,
            open_on_weekends,
        } = request.body;
    
        const orphanagesRepository = getRepository(Orphanage);
    
        const requestImages = request.files as Express.Multer.File[];
        
        const images = requestImages.map(image=>{
            return{ path: image.filename}
        })

        const data = {
            name,
            latitude,
            longitude,
            about,
            instructions,
            opening_hours,
            open_on_weekends,
            images,
        };

        const schema = yup.object().shape({
            name: yup.string().required('Campo "Nome" obrigatório'),
            latitude: yup.number().required('Campo "Latitude" obrigatório'),
            longitude: yup.number().required('Campo "Longitude" obrigatório'),
            about: yup.string().required('Campo "Sobre" obrigatório').max(300),
            instructions: yup.string().required('Campo "Instruções" obrigatório'),
            opening_hours: yup.string().required('Campo "Horario de Funcionamento" obrigatório'),
            open_on_weekends: yup.boolean().required('Campo "Aberto aos finais de semana" obrigatório'),
            images: yup.array(
                yup.object().shape({
                path: yup.string().required()
            }))

        });

        await schema.validate(data, {
            abortEarly: false,
        });

        const orphanage = orphanagesRepository.create(data);
    
        await orphanagesRepository.save(orphanage);
    
        return response.status(201).json(orphanage);
    }
};
import React from 'react';
import Routes from './routes';

import './css/global.css';
import './css/landing.css';

function App() {
  return(
    <Routes />
  );
}

export default App;
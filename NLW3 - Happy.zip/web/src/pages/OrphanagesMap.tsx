import React from 'react';
import { Link } from 'react-router-dom';
import { FiArrowRight, FiPlus } from 'react-icons/fi';
import { Map, TileLayer, Marker, Popup } from 'react-leaflet';
import Leaflet from 'leaflet';

import "leaflet/dist/leaflet.css";
import "../css/orphanagesMap.css";
import "../css/orphanage.css";
import "../css/create-orphanage.css";

import mapMarker from "../images/map-marker.svg";
import { useEffect, useState } from "react";
import api from '../services/api';
import Orphanage from './Orphanage';

interface Orphanage{
    id: number;
    latitude: number;
    longitude: number;
    name: string;
    about: string;
    instructions: string;
    opening_hours: string;
    open_on_weekends: string;
}

const mapIcon = Leaflet.icon({
    iconUrl: mapMarker,
    iconAnchor: [29, 68],
    iconSize: [40, 40],
    popupAnchor: [165, -15],
});

function OrphanagesMap() {
    const [orphanages, setOrphanages] = useState<Orphanage[]>([]);

    useEffect(() => {
        api.get('orphanages').then(response =>{

            console.log(response);

            setOrphanages(response.data);
        });
    },[]);  

    return (
        <div id="pageMap">
            <aside>
                <header>
                    <img src={mapMarker} alt="Happy" />

                    <h2>Escolha um orfanato no mapa!</h2>
                    <p>Muitas crianças estão esperando a sua visita :)</p>
                </header>
                <footer>
                    <strong>Araucária</strong>
                    <span>Paraná</span>
                </footer>
            </aside>

            <Map center={[-25.5864602, -49.4109103]} zoom={14.45} style={{ width: "100%", height: "100%" }}>
                {/*<TileLayer url="https://a.tile.openstreetmap.org/{z}/{x}/{y}.png" />*/}
                <TileLayer url={`https://api.mapbox.com/styles/v1/mapbox/dark-v10/tiles/256/{z}/{x}/{y}@2x?access_token=${process.env.REACT_APP_MAPBOX_TOKEN}`} />

                {orphanages.map(orphanage => {
                return(
                    <Marker 
                        position={[orphanage.latitude, orphanage.longitude]} 
                        icon={mapIcon}
                    >
                        <Popup closeButton={false} minWidth={240} maxWidth={240} className="map-popup">
                            {orphanage.name}
                            <Link to={`/orphanages/${orphanage.id}`}>
                                <FiArrowRight size={20} color="#FFF" />
                            </Link>
                        </Popup>
                    </Marker>
                )
            })}

            </Map>

            <Link to="/orphanages/create" className="createOrphanage">
                <FiPlus size={32} color="#FFF" />
            </Link>
        </div>
    );
}

export default OrphanagesMap;